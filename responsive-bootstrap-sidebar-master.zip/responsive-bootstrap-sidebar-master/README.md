# Responsive-bootstrap-sidebar
Responsive Bootstrap Sidebar with Collapsed control
[![Github All Releases](https://img.shields.io/github/downloads/nkmswot/responsive-bootstrap-sidebar/total.svg)]()


Read [Documentation](https://8subjects.com/responsive-bootstrap-sidebar/)

### Featued on [FreeCMSThemes]( https://freecmsthemes.com/responsive-bootstrap-sidebar/)

## Features
* 3 different themes
* 8 different colorful templates.
* light weight CSS, JS.

![Big Icon Menu](https://swot.co.in/advt/big-icon-menu.png)

![Icon Menu](https://swot.co.in/advt/icon-menu.png)

![Text Menu](https://swot.co.in/advt/text-menu.png)






